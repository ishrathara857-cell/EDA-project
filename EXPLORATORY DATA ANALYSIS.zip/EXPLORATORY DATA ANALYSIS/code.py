import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

# Page Title
st.set_page_config(page_title="Student Performance Analysis")

st.title("📚 Student Performance Analysis")
st.write("Simple EDA Project using Streamlit")

# Load Dataset
df = pd.read_csv("StudentsPerformance.csv")

# Show Dataset
st.subheader("Dataset Preview")
st.dataframe(df.head())

# Dataset Information
st.subheader("Dataset Information")

col1, col2 = st.columns(2)

with col1:
    st.metric("Rows", df.shape[0])

with col2:
    st.metric("Columns", df.shape[1])

# Missing Values
st.subheader("Missing Values")
st.write(df.isnull().sum())

# Summary Statistics
st.subheader("Summary Statistics")
st.write(df.describe())

# Average Scores
st.subheader("Average Scores")

math_avg = round(df["math score"].mean(), 2)
reading_avg = round(df["reading score"].mean(), 2)
writing_avg = round(df["writing score"].mean(), 2)

c1, c2, c3 = st.columns(3)

c1.metric("Math", math_avg)
c2.metric("Reading", reading_avg)
c3.metric("Writing", writing_avg)

# Histogram
st.subheader("Score Distribution")

subject = st.selectbox(
    "Select Subject",
    ["math score", "reading score", "writing score"]
)

fig, ax = plt.subplots()
ax.hist(df[subject], bins=10)
ax.set_title(subject)
ax.set_xlabel("Score")
ax.set_ylabel("Number of Students")

st.pyplot(fig)

# Gender Distribution
st.subheader("Gender Distribution")

gender_count = df["gender"].value_counts()

fig2, ax2 = plt.subplots()
gender_count.plot(kind="bar", ax=ax2)

ax2.set_xlabel("Gender")
ax2.set_ylabel("Count")
ax2.set_title("Male vs Female Students")

st.pyplot(fig2)

# Total Score
df["Total Score"] = (
    df["math score"]
    + df["reading score"]
    + df["writing score"]
)

# Top Students
st.subheader("Top 10 Students")

top_students = df.sort_values(
    by="Total Score",
    ascending=False
).head(10)

st.dataframe(top_students)

# Download Option
st.subheader("Download Updated Dataset")

csv = df.to_csv(index=False)

st.download_button(
    label="Download CSV",
    data=csv,
    file_name="student_performance_updated.csv",
    mime="text/csv"
)

st.success("EDA Completed Successfully!")